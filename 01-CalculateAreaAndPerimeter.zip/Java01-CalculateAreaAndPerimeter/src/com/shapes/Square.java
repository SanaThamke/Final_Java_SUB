package com.shapes;

public class Square implements IShape {

	private Double side;
	
	
	public Square(Double side) {
		super();
		this.side = side;
	}

	@Override
	public Double calculateArea() {
		return side*side;
	}

	@Override
	public Double calculatePerimeter() {
		return 4*side;
	}

}
