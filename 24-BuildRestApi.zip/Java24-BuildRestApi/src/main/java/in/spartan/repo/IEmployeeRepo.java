package in.spartan.repo;

import org.springframework.data.repository.CrudRepository;

import in.spartan.model.Employee;

public interface IEmployeeRepo extends CrudRepository<Employee,Integer>{

}
