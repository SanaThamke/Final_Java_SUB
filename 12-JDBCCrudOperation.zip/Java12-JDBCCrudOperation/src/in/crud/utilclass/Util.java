package in.crud.utilclass;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.*;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

public class Util {
	
	static {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			System.out.println("Error!!!! ,Driver class not found");
		}
	}
	
	public static Connection getConnection() throws SQLException, IOException
	{
		String config="F:\\JavaPrograms\\JdbcCrudapp\\src\\propertyfile\\propertydata";
		HikariConfig hc=new HikariConfig(config);
		
		HikariDataSource dataSource=new HikariDataSource(hc);
		Connection connect=dataSource.getConnection();
		return connect;
		
	}
	

}
