package in.crud.persistencelayer;

import java.io.IOException;
import java.sql.*;

import in.crud.datatransferobject.Student;
import in.crud.utilclass.Util;

public class StudentDaoImpl implements IStudentDao {

	
	@Override
	public String addStudent(String sname, Integer sage, String saddress) {
		Connection connection=null;
		PreparedStatement pst=null;
		try 
		{			
			connection=Util.getConnection();
			String myQuery="Insert into studentdata(sname,sage,saddress) values(?,?,?)";
			pst=connection.prepareStatement(myQuery);
			//Set the values
			if(pst!=null) {
				pst.setString(1, sname);
				pst.setInt(2, sage);
				pst.setString(3, saddress);
			}
			//Execute the Query
			int rows=pst.executeUpdate();
			if(rows==1)
			{
				return "Success";
			}
		}
		catch (SQLException | IOException e) {
			e.printStackTrace();
		}
		
		return "Failed";
	}

	@Override
	public Student searchStudent(Integer id) {
		Connection connection=null;
		PreparedStatement pst=null;
		ResultSet resultSet =null;
		Student std=null;
		try 
		{			
			connection=Util.getConnection();
			String myQuery="select sid,sname,sage,saddress from studentdata where sid=?";
			pst=connection.prepareStatement(myQuery);
			//Set the values
			if(pst!=null) {
				pst.setInt(1, id);
			}
			//Execute the Query
			resultSet = pst.executeQuery();
			if(resultSet.next())
			{
				std=new Student();
				std.setSid(resultSet.getInt(1));
				std.setSname(resultSet.getString(2));
				std.setSage(resultSet.getInt(3));
				std.setSaddress(resultSet.getString(4));
				return std;
			}
				
		}
		catch (SQLException | IOException e) {
			e.printStackTrace();
		}
		
		return std;
	}

	@Override
	public String deleteStudent(Integer sid) {
		Connection connection=null;
		PreparedStatement pst=null;
		try
		{
			connection=Util.getConnection();
			String myQuery="delete from studentdata where sid=?";
			pst=connection.prepareStatement(myQuery);
			if(pst!=null)
			{
				pst.setInt(1, sid);
				int rows=pst.executeUpdate();
				if(rows==1)
				   return "Success";
				else
					return "not found";
			}
		}
		catch(IOException | SQLException io) {
			io.printStackTrace();
			return "failure";
		}
		return "Failed";
	}

	@Override
	public String updateStudent(Student student) {
		
		Connection connection=null;
		PreparedStatement pst=null;
		try
		{
			connection=Util.getConnection();
			String myQuery="update studentdata set sname=?,sage=?,saddress=? where sid=?";
			pst=connection.prepareStatement(myQuery);
			pst.setString(1, student.getSname());
			pst.setInt(2, student.getSage());
			pst.setString(3, student.getSaddress());
			pst.setInt(4, student.getSid());
			
			//Execute
			int rows=pst.executeUpdate();
			if(rows==1)
			   return "Success";
			else
				return "not found";
	    }
		catch(IOException | SQLException io) {
			io.printStackTrace();
			return "failure";
		}

    }
}
