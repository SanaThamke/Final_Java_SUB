package in.ineuron;

import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import in.ineuron.model.Employee;
import in.ineuron.repository.EmployeeServiceImpl;


@SpringBootApplication
public class Java21InsertionUsingDataJpaApplication {

	
	public static void main(String[] args) {
		ConfigurableApplicationContext run = SpringApplication.run(Java21InsertionUsingDataJpaApplication.class, args);
		EmployeeServiceImpl bean = run.getBean(EmployeeServiceImpl.class);
		
		 Scanner scan=new Scanner(System.in);
		
		 System.out.println("ENTER YOUR NAME::");
		 String name=scan.next();
		 System.out.println("ENTER EMAIL::");
		 String email=scan.next();
		 System.out.println("ENTER MOBILE::");
		 Long mobile=scan.nextLong();
		 System.out.println("ENTER EXPERIENCE::");
		 int exp=scan.nextInt();
		 
		 Employee emp=new Employee(null,name, email, mobile, exp);
		 String status = bean.registerEmployee(emp);
		 System.out.println(status);
		 
		 scan.close();
	}

}
