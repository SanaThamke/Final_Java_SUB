package in.ineuron.sevice;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.ineuron.model.Order;
import in.ineuron.model.User;
import in.ineuron.repository.IOrderRepo;

@Service
public class OrderServiceImpl implements IOrderService{

	@Autowired
	private IOrderRepo orderRepo;
	
	@Override
	public List<Order> getAllOrders() {
		return (List<Order>) orderRepo.findAll();
	}

	@Override
	public List<Order> getOrderByUser(User user) {
		return (List<Order>) orderRepo.findByUser(user);
	}

	@Override
	public String saveOrder(Order order) {
		return "Oeder added with id::"+orderRepo.save(order).getId();
	}

}
