package in.spartan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Java23RegisterAndLoginUsersApplication {

	public static void main(String[] args) {
		SpringApplication.run(Java23RegisterAndLoginUsersApplication.class, args);
	}

}
