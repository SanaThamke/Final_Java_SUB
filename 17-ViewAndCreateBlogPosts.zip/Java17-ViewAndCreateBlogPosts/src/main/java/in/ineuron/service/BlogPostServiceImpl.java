package in.ineuron.service;

import java.util.List;

import in.ineuron.dao.IBlogPostDao;
import in.ineuron.daofactory.BlogPostDaoFactory;
import in.ineuron.model.BlogPost;

public class BlogPostServiceImpl implements IBlogPostService {

	private IBlogPostDao blogPostDao=null;
	
	@Override
	public String createPost(BlogPost post) {
		blogPostDao=BlogPostDaoFactory.getBlogPostDao();
		return blogPostDao.createPost(post);
	}

	@Override
	public List<BlogPost> viewPosts() {
		blogPostDao=BlogPostDaoFactory.getBlogPostDao();
		return blogPostDao.viewPosts();
	}

}
