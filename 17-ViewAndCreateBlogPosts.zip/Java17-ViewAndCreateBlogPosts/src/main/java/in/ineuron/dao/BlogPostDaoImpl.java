package in.ineuron.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import in.ineuron.model.BlogPost;
import in.ineuron.utility.UtilityClass;

public class BlogPostDaoImpl implements IBlogPostDao{

	Connection connection=null;
	PreparedStatement pst=null;
	ResultSet resultSet=null;
	
	@Override
	public String createPost(BlogPost post) {
		
		try 
		{			
			connection=UtilityClass.getConnect();
			String myQuery="Insert into blogpost(title,description,content) values(?,?,?)";
			pst=connection.prepareStatement(myQuery);
			
			//Set the values
			if(pst!=null) {
				pst.setString(1, post.getTitle());
				pst.setString(2, post.getDescription());
				pst.setString(3, post.getContent());
			}
			//Execute the Query
			int rows=pst.executeUpdate();
			if(rows==1)
			{
				return "Created successfully";
			}
		}
		catch (SQLException | IOException e) {
			e.printStackTrace();
		}
		
		return "Failed,Try again after sometime..";
	}

	@Override
	public List<BlogPost> viewPosts() {
		
		List<BlogPost> posts=new ArrayList<BlogPost>();
		BlogPost post=null;
		try 
		{			
			connection=UtilityClass.getConnect();
			String myQuery="select title,description,content from blogpost";
			pst=connection.prepareStatement(myQuery);
			
			//Execute the Query
			resultSet = pst.executeQuery();
			while(resultSet.next())
			{
				post=new BlogPost();

				post.setTitle(resultSet.getString("title"));
				post.setDescription(resultSet.getString("description"));
				post.setContent(resultSet.getString("content"));
				
				posts.add(post);
			}
				
		}
		catch (SQLException | IOException e) {
			e.printStackTrace();
		}
		
		return posts;
	}

}
