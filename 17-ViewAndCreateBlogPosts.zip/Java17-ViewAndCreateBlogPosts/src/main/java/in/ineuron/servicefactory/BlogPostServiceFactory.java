package in.ineuron.servicefactory;

import in.ineuron.service.BlogPostServiceImpl;
import in.ineuron.service.IBlogPostService;


public class BlogPostServiceFactory {
	
	static IBlogPostService blogPostService=null;
	//Make constructor private to avoid object creation(Singleton)
	private BlogPostServiceFactory()
	{
		
	}
	public static IBlogPostService getBlogPostService()
	{
		blogPostService=new BlogPostServiceImpl();
		return blogPostService;
		
	}
	

}
