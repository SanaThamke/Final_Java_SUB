package in.ineuron.dao;

import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.query.NativeQuery;
import org.hibernate.query.Query;

import in.ineuron.model.CricketerBO;
import in.ineuron.util.Utility;

public class CricketerDaoLayer {
	
	public void getDatas() {
		
		Session session=null;

		try {
			session=Utility.getSession();
			
			Query<CricketerBO> query=session.createQuery("FROM in.ineuron.model.CricketerBO");
			List<CricketerBO> list = query.getResultList();
			for(CricketerBO bo:list) {
				System.out.println(bo);
			}
			
		}catch(HibernateException he)
		{
			he.getMessage();
		}catch(Exception e) {
			e.getLocalizedMessage();
		}
		finally {
			Utility.closeSession(session);
			Utility.closeSessionFactory();
		}
		
		
	}
	

}
