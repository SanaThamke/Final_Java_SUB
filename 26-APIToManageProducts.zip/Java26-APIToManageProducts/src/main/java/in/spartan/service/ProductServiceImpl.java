package in.spartan.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.spartan.exception.ProductNotFoundException;
import in.spartan.model.Product;
import in.spartan.repo.IProductRepo;;

@Service
public class ProductServiceImpl implements IProductService {

	
	@Autowired
	private IProductRepo repo;
	
	@Override
	public String saveEmployee(Product product) {
		Integer id = repo.save(product).getId();
		if(id!=-1)
		   return "Succesfully registered with given id::"+id;
		else
			return "Registration failed";
	}
	
	@Override
	public List<Product> getAllProduct() {
		return (List)repo.findAll();
	}

	@Override
	public Product getProductById(Integer id)throws ProductNotFoundException  {
		Optional<Product> optional = repo.findById(id);
		if(optional.isPresent()) {
			return optional.get();
		}else {
		   throw new ProductNotFoundException("Product not found for id::"+id);
		}
	}

	@Override
	public String updateProduct(Product product)throws ProductNotFoundException  {
		Optional<Product> option = repo.findById(product.getId());
		if(option.isPresent()) {
			repo.save(product);
			return "Updated Successfully with Id:: "+product.getId();
		}else {
		    throw new ProductNotFoundException("Product not found for id::"+product.getId());
		}
	}


	@Override
	public String deleteProduct(Integer id) throws ProductNotFoundException {
		Optional<Product> option =repo.findById(id);
		if(option.isPresent()) {
			repo.delete(option.get());
			return "Deleted Successfully with Id:: "+id;
		}else {
		    throw new ProductNotFoundException("Product not found for id::"+id);
		}
	}

}
