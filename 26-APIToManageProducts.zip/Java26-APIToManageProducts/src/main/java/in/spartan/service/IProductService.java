package in.spartan.service;

import java.util.List;

import in.spartan.exception.ProductNotFoundException;
import in.spartan.model.Product;

public interface IProductService {

	public String saveEmployee(Product product);
	public List<Product> getAllProduct();
	public Product getProductById(Integer id)throws ProductNotFoundException ;
	public String updateProduct(Product product)throws ProductNotFoundException ;
	public String deleteProduct(Integer id)throws ProductNotFoundException ;
}
