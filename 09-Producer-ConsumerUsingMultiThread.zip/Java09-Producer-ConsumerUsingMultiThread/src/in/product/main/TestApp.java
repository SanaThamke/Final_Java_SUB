package in.product.main;

import java.util.Scanner;

import in.product.producer.ProducerConsumer;

public class TestApp {

	 public static void main(String[] args)throws InterruptedException
     {
		 Scanner scan=new Scanner(System.in);
		       
		        final ProducerConsumer producer = new ProducerConsumer();

		        // Create producer thread
		        Thread t1 = new Thread(new Runnable() {
		            @Override
		            public void run()
		            {
		                try {
		                    producer.produce();
		                }
		                catch (InterruptedException e) {
		                    e.printStackTrace();
		                }
		            }
		        });
		 
		        // Create consumer thread
		        Thread t2 = new Thread(new Runnable() {
		            @Override
		            public void run()
		            {
		                try {
		                    producer.consume();
		                }
		                catch (InterruptedException e) {
		                    e.printStackTrace();
		                }
		            }
		        });
		 
		        // Start both threads
		        t1.start();
		        t2.start();
		 
		    }

}
