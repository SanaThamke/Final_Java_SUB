package com.main;

import java.util.Scanner;

import com.bankOffers.Balance;
import com.bankOffers.Deposit;
import com.bankOffers.Withdrawl;
import com.server.Server;

public class TestApp {

	public static void main(String[] args) throws Exception {
		Scanner s =new Scanner(System.in);
		boolean flag=true;
		Server server=null;
		while(flag)
		{
			System.out.println();
			System.out.println();
			System.out.println();
			System.out.println("................ BANKING APPLICATION.................... ");
			System.out.println();
			System.out.println("1. Withdrawl");
			System.out.println("2. Deposit");
			System.out.println("3. Check Balance");
			System.out.println("4. Exit");
			System.out.println();
			System.out.println("ENETR YOUR OPTION");
			int choice=s.nextInt();
			if(choice==1)
			{
				server=new Withdrawl();
				server.input();
				server.verifyUser();
			}
			else if(choice==2)
			{
				server=new Deposit();
				server.input();
				server.verifyUser();
			}
			else if(choice==3)
			{
				server =new Balance();
				server.input();
				server.verifyUser();
			}
			else
			{
				flag=false;
				System.exit(0);
			}
				
		}
	}
}
