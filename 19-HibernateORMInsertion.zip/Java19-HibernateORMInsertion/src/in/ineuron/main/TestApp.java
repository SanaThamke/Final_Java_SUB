package in.ineuron.main;

import java.util.Scanner;

import in.ineuron.dao.CricketerDaoLayer;
import in.ineuron.model.CricketerBO;

public class TestApp {
	
	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);

		System.out.print("Enter the Player name :: ");
		String name = scanner.next();

		System.out.print("Enter the PLayer franchise :: ");
		String franchise= scanner.next();

		System.out.print("Enter the Player team:: ");
		String team = scanner.next();

		CricketerBO bo=new CricketerBO();
		bo.setName(name);
		bo.setFranchise(franchise);
		bo.setTeam(team);
		
		CricketerDaoLayer cric=new CricketerDaoLayer();
		int id= cric.registerCricketer(bo);
		if(id==-1)	
			System.out.println("Registration failed");
		else
			cric.getDatas(id);
		
		
	}

}
