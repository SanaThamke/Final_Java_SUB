package com.parent;

public class Loan {

	public Loan() {
		System.out.println("Statement is from Loan (parent) object");
		System.out.println("Just invoked the parent class constructor");
	}
}
