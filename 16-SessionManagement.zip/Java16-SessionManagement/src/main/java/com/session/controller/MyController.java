package com.session.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalTime;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/welcome")
public class MyController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out = response.getWriter();
		String name= request.getParameter("name");
		
		HttpSession session = request.getSession();	
		session.setAttribute("name", name);
		
		out.println("<h1>Session Id is"+session.getAttribute("name")+"</h1>");
		
		RequestDispatcher rd = null;
		rd = request.getRequestDispatcher("./resp.jsp");
		rd.forward(request, response);
	}

}
